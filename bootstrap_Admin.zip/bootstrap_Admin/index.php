<!doctype html>
<html>
<head>
<meta charset="utf-8">
<meta name="viewport" content="initial-scale=1.0">
<title>Admin Panel</title>
<link rel="stylesheet" href="css/bootstrap.min.css" type="text/css" media="all">
<link rel="stylesheet" href="css/style.css" type="text/css" media="all">
<link rel="stylesheet" href="css/font-awesome.min.css" type="text/css" media="all">

</head>
<body class="bgform" >

<header class="header">
		<div class="pull-left p-3">
			<a href="#">
			<b>Admin App</b>
			</a>
		</div>

	<!-- start: search & user box -->
	<div class="pull-right">

		<div class="profile-info p-2">
			<span class="name">Super Admin</span>
			<br>
			<a href="https://localhost/eckolimo/login/logout"><i class="fa fa-power-off" aria-hidden="true"></i>
			Logout</a>
		</div>
	</div>
</header>

<div class="full">
<a href="#">
	<i class="fa fa-rss fontcolor pull-left" aria-hidden="true"></i>
	<span class="spandiv">Add/Edit Blogs</span>
	</a>
   <div class="col-md-1 pull-left padd0 fixed zi" style="margin-top: 50px" >  
    <div class="navh1">
	<ul class="nav " >
	<li>
	<a href="#">
	<i class="fa fa-rss fontcolor pull-left" aria-hidden="true"></i>
	<span class="spandiv fontcolor">Add/Edit Blogs</span>
	</a>
	</li>
	<li>
	<a href="#">
	<i class="fa fa-bookmark fontcolor pull-left" aria-hidden="true"></i>
	<span  class="spandiv fontcolor">Add Newsletters</span>
	</a>
	</li>

	<li>
	<a href="#">
	<i class="fa fa-th fontcolor pull-left" aria-hidden="true"></i>
	<span class="spandiv fontcolor">Master Page Seetings</span>
	</a>
	</li>

	<li>
	<a href="#">
	<i class="fa fa-picture-o fontcolor pull-left" aria-hidden="true"></i>
	<span class="spandiv fontcolor">Images Upload</span>
	</a>
	</li>


	

	
	</ul>
     </div>	
    </div>
<!--  End header	 -->


<!--  Body Form Strat	 -->	
<header class="page-header border fixed w100" style="border:none !important">
  <i class="fa fa-bars fontcolor pull-left navbgclr pointer" style="padding-right:36px" aria-hidden="true" onclick="shownav()"></i>
  <h4>Blog Page</h4>
  <div class="pull-right p-2">
  	<a class="btn btn-primary btn-sm col-w" id="addForm" >Add New Records</a>
  </div>
</header>
	
<div class="col-md-11 pull-right padd0 mt-5 res-mgtop ">
<div class="container-fluid mt-4 pr-5 res-pad">
  <div class="row">
   <div class="col-md-12 padd0 hide mb-4" id="addRecord">
	<form id="form" method="POST" enctype="multipart/form-data" class="form-vertical">
               
        <div class="text-left p-3 bgcolor">
            <div class="col-md-4 float-right">
                <button type="reset" class="btn btn-default float-right btn-sm">Reset</button>                     
                 <button class="btn btn-primary btn-sm float-right">Submit</button>
            </div>
            <div class="col-md-2">
              <h5 class="panel-title col-b">Form</h5>
            </div>
        </div>

        <div class="panel-body">
                    <div class="form-row p-3">
                        <div class="col-sm-3">
                            <label class=" control-label">Page Url Name <span class="required">*</span></label>
                            <input type="text" name="page_name" class="form-control" placeholder="Page name" value="" required/>
                        </div>

                        <div class="col-sm-3">
                            <label class=" control-label">Title <span class="required">*</span></label>
                            <input type="text" name="title" class="form-control" placeholder="Title" value="" required/>
                        </div>

                        <div class="col-sm-3">
                            <label class=" control-label">SEO <span class="required">*</span></label>
                            <input type="text" name="seo" class="form-control" placeholder="SEO" value="" required/>
                        </div>

                    </div>

				 	<div class="form-row p-3">
                    	<div class=" col-sm-12">
                            <label class=" control-label">Css/Js Extra Links</label>
                            <textarea name="css_js" class="form-control" placeholder="Css/Js Extra Links" rows="2"></textarea>
                  		</div>
                    </div>

                    <div class="form-row p-3">    
                        <div class=" col-sm-12">
                            <label class=" control-label">Description <span class="required">*</span></label>
                            <textarea name="data[]" class="textarea form-control" placeholder="Description" rows="20" required=""></textarea>
                        </div>
                    </div>
                        
        </div>
              
    </form>
	</div>

	<div class="col-md-12 padd0 mt-2 pb-4">
	
	 <div class="text-left p-3 bgcolor">
           <h5 class="panel-title col-b">Blog Page Records</h5>
        </div>

        <div class="panel-body p-3">
            <div class="row ">
                <div class="col-md-12 table-responsive">
                    <table class="table table-bordered table-striped" >
                        <thead>
                            <tr>
                                <th>Sr. No</th>
                                <th>Title</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
<tr>
<td>1</td>
<td>
<a href="#">
new blog</a>

</td>                        
<td>
Update Status/Delete                  
</td>                             
</tr>                            

<tr>
<td>2</td>
<td>
<a href="#">
testing</a>

</td>                        
<td>
Update Status/Delete                   
</td>                             

</tr>
<tr>
<td>3</td>
<td>
<a href="#">
Everything You Need to Know About Chartering a Bus</a>

</td>                        
<td>
Update Status/Delete                  
</td>                             
</tr>                            

<tr>
<td>4</td>
<td>
<a href="#">
What Exactly is Excellent Customer Service?</a>
</td>                        
<td>
	Update Status/Delete                   
</td>                             

</tr>
<tr>
<td>5</td>
<td>
<a href="#">
Halloween 2020 - By the Numbers</a>
</td>                        
<td>
Update Status/Delete                  
</td>                             

</tr>
                    
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </section>
    <!-- end: Listing Records -->
	</div>

  </div>
</div>		
</div>
<!--  Body Form End	 -->	

</div>

<!-- Footer Section Script and CSS -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.1/css/all.min.css" type="text/css" media="all">
<script src="js/jquery-3.3.1.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<!-- Footer Section Script and CSS -->
<script type="text/javascript">
function shownav(){
    $('.navh1').toggle();
}

 $('#addForm').click(function(){
        $('#addRecord').slideToggle();
        $('#addForm').hide();
      });

</script>
</body>
</html>
