<!doctype html>
<html>
<head>
<meta charset="utf-8">
<meta name="viewport" content="initial-scale=1.0">
<title>Admin Panel</title>
<link rel="stylesheet" href="css/bootstrap.min.css" type="text/css" media="all">
<link rel="stylesheet" href="css/style.css" type="text/css" media="all">
<link rel="stylesheet" href="css/font-awesome.min.css" type="text/css" media="all">
<!-- <link href="https://fonts.googleapis.com/css?family=Roboto:100,100i,300,300i,400,400i,500,500i,700,700i,900,900i&display=swap" rel="stylesheet"> -->
<script src="js/jquery-3.3.1.min.js"></script>
<script src="js/bootstrap.min.js"></script>
</head>
<body class="bgform" style="padding: 9%">
    <div class="container-fluid">
        <div class="row">
        	<div class="col-md-5 m-auto rounded">
				<form id="form" method="post" class="border form-vertical" enctype="multipart/form-data"> 
					<div class="text-left p-3 bgcolor">
						<h5>Login Form</h5>
					</div>
					              
				<div class="panel-body p-4 ">
						<div class="form-group ">
							<input type="text" name="email" class="form-control" placeholder="Mobile/Email">
						</div>
						<div class="form-group  ">
							<input type="password" name="password" class="form-control" placeholder="Password">
						</div>
                       <div class="form-group ">
                              <div class="input-group">
								<button class="btn btn-primary">Submit</button>
								<button type="reset" class="btn btn-default">Reset</button>
                                <p style="float: right;margin:5px 0 0 20px;"></p>
                             </div>
						</div>  
					</div>
					<div class="text-center p-3 bgcolor">
						Admin App©2019-2020
					</div>
			</form>
			</div>
        </div>
    </div>
</body>
</html>
